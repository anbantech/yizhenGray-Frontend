interface ProjectBaseConfig {
  is_emulated: boolean
  logo: boolean
}

interface Window {
  PROJECT_BASE_CONFIG: ProjectBaseConfig
}
